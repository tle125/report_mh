
import { GoogleGenAI } from "@google/genai";
import { RepairRecord } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function generateReportSummary(data: RepairRecord[]): Promise<string> {
  const dataString = JSON.stringify(data, null, 2);
  
  const prompt = `
    You are an expert data analyst for a vehicle fleet manager.
    Based on the following JSON data of vehicle repair records, provide a concise summary in Thai language.
    The currency is in Thai Baht (บาท).

    The summary should include:
    1.  จำนวนการซ่อมทั้งหมด (Total number of repairs).
    2.  ค่าใช้จ่ายในการซ่อมทั้งหมด (Total cost of all repairs).
    3.  รถที่มียอดซ่อมสูงสุด (The vehicle with the highest total repair cost).
    4.  ประเภทการซ่อมที่พบบ่อยที่สุด (The most common type of repair, e.g., 'ซ่อมแซม' or 'บำรุงรักษา').
    5.  รายการซ่อมที่มีค่าใช้จ่ายสูงที่สุด (The single repair item with the highest cost).

    Present the summary in clear, easy-to-read markdown bullet points. Do not include the original data in your response.

    JSON Data:
    ${dataString}
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error) {
        return `เกิดข้อผิดพลาดในการสร้างสรุป: ${error.message}`;
    }
    return "เกิดข้อผิดพลาดที่ไม่รู้จักในการสร้างสรุป";
  }
}
