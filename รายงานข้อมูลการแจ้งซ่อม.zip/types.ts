
export interface RepairRecord {
  id: number;
  vehicleNo: string;
  repairItem: string;
  type: string;
  appWorkOrderNo: string;
  sapWorkOrderNo: string;
  sapDocDate: string;
  appRequestDate: string;
  appCompletionDate: string;
  price: number;
}
