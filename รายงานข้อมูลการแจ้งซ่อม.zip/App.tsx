
import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { RepairRecord } from './types';
import { generateReportSummary } from './services/geminiService';
import ReportTable from './components/ReportTable';
import SummaryCard from './components/SummaryCard';
import SpinnerIcon from './components/icons/SpinnerIcon';
import Sidebar from './components/Sidebar';
import RepairCostChart from './components/RepairCostChart';
import FilterControls from './components/FilterControls';
import Dashboard from './components/Dashboard';

// The Google Apps Script URL is now hardcoded and will not be changed by the user.
const SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbwp0yu3ryGYYaaSIkTkOs64BFI3CYllPcQPJe3HcpldhPqHnggmmjTC1uSOV_xHLpUh/exec';

// Define the sort configuration interface
interface SortConfig {
  key: keyof RepairRecord;
  direction: 'ascending' | 'descending';
}

type GroupByOption = 'month' | 'type';
type ViewOption = 'dashboard' | 'table';

const App: React.FC = () => {
  const [reportData, setReportData] = useState<RepairRecord[]>([]);
  
  const [isFetchingData, setIsFetchingData] = useState(true); // Start in loading state
  const [fetchError, setFetchError] = useState<string | null>(null);

  const [summary, setSummary] = useState<string | null>(null);
  const [isGeneratingSummary, setIsGeneratingSummary] = useState<boolean>(false);
  const [summaryError, setSummaryError] = useState<string | null>(null);
  
  const [sortConfig, setSortConfig] = useState<SortConfig | null>({ key: 'id', direction: 'ascending' });
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedMonth, setSelectedMonth] = useState('');
  const [groupBy, setGroupBy] = useState<GroupByOption>('month');
  const [view, setView] = useState<ViewOption>('dashboard');

  const refreshAndResetData = useCallback(async () => {
    setIsFetchingData(true);
    setFetchError(null);
    // Reset all states to default before fetching new data
    setReportData([]);
    setSummary(null);
    setSummaryError(null);
    setSortConfig({ key: 'id', direction: 'ascending' });
    setSearchTerm('');
    setSelectedMonth('');
    setGroupBy('month');
    setView('dashboard');

    try {
      const url = new URL(SCRIPT_URL);
      url.searchParams.append('timestamp', Date.now().toString());

      const response = await fetch(url.toString(), {
        method: 'GET',
        redirect: 'follow'
      });
      
      if (!response.ok) {
        throw new Error(`เกิดข้อผิดพลาดจาก Server: ${response.status} ${response.statusText}`);
      }

      const result = await response.json();

      if (result.success === false) {
        throw new Error(result.error || 'สคริปต์ทำงานผิดพลาด แต่ไม่ระบุสาเหตุ');
      }

      setReportData(result.data);

    } catch (err) {
      console.error("Error fetching data:", err);
      if (err instanceof Error) {
        setFetchError(`ไม่สามารถดึงข้อมูลได้: ${err.message}. โปรดตรวจสอบว่า URL ถูกต้อง, สคริปต์ถูก Deploy และตั้งค่าการเข้าถึงเป็น "Anyone"`);
      } else {
        setFetchError('เกิดข้อผิดพลาดที่ไม่รู้จักขณะดึงข้อมูล');
      }
    } finally {
      setIsFetchingData(false);
    }
  }, []);

  // Automatically fetch data when the component mounts for the first time.
  useEffect(() => {
    refreshAndResetData();
  }, [refreshAndResetData]);


  const availableMonths = useMemo(() => {
    const months = new Set<string>();
    reportData.forEach(record => {
      if (record.sapDocDate) {
        const date = new Date(record.sapDocDate);
        if (!isNaN(date.getTime())) {
          const monthYear = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
          months.add(monthYear);
        }
      }
    });
    return Array.from(months).sort().reverse();
  }, [reportData]);

  const filteredData = useMemo(() => {
    return reportData
      .filter(record => {
        if (!selectedMonth) return true;
        if (!record.sapDocDate) return false;
        const date = new Date(record.sapDocDate);
        const monthYear = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
        return monthYear === selectedMonth;
      })
      .filter(record => {
        if (!searchTerm) return true;
        const lowerCaseSearchTerm = searchTerm.toLowerCase();
        return Object.values(record).some(value => 
          String(value).toLowerCase().includes(lowerCaseSearchTerm)
        );
      });
  }, [reportData, searchTerm, selectedMonth]);
  
  const sortedData = useMemo(() => {
    let sortableItems = [...filteredData];
    if (sortConfig !== null) {
      sortableItems.sort((a, b) => {
        const aValue = a[sortConfig.key];
        const bValue = b[sortConfig.key];

        // Handle date sorting for sapDocDate
        if (sortConfig.key === 'sapDocDate' || sortConfig.key === 'appRequestDate' || sortConfig.key === 'appCompletionDate') {
            const dateA = new Date(aValue).getTime();
            const dateB = new Date(bValue).getTime();
            if (dateA < dateB) return sortConfig.direction === 'ascending' ? -1 : 1;
            if (dateA > dateB) return sortConfig.direction === 'ascending' ? 1 : -1;
            return 0;
        }

        if (aValue < bValue) {
          return sortConfig.direction === 'ascending' ? -1 : 1;
        }
        if (aValue > bValue) {
          return sortConfig.direction === 'ascending' ? 1 : -1;
        }
        return 0;
      });
    }
    return sortableItems;
  }, [filteredData, sortConfig]);

  const handleSort = (key: keyof RepairRecord) => {
    let direction: 'ascending' | 'descending' = 'ascending';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    setSortConfig({ key, direction });
  };


  const handleGenerateSummary = useCallback(async () => {
    if (sortedData.length === 0) return;

    setIsGeneratingSummary(true);
    setSummaryError(null);
    setSummary(null);
    try {
      const result = await generateReportSummary(sortedData);
      setSummary(result);
    } catch (err) {
      if (err instanceof Error) {
        setSummaryError(err.message);
      } else {
        setSummaryError('An unknown error occurred.');
      }
    } finally {
      setIsGeneratingSummary(false);
    }
  }, [sortedData]);
  
  const hasInitialData = reportData.length > 0;
  const hasFilteredData = sortedData.length > 0;
  
  const renderMainContent = () => {
    if (isFetchingData) {
        return (
            <div className="w-full h-full flex flex-col items-center justify-center text-slate-500">
                <SpinnerIcon className="w-16 h-16 mb-4" />
                <p className="text-xl font-semibold">กำลังดึงข้อมูลจาก Google Sheet...</p>
                <p>กรุณารอสักครู่</p>
            </div>
        );
    }

    if (fetchError) {
        return (
             <div className="mt-4 max-w-2xl mx-auto text-sm text-red-600 bg-red-50 p-4 rounded-lg shadow">
                <p className="font-bold">เกิดข้อผิดพลาดในการเชื่อมต่อ:</p>
                {fetchError}
              </div>
        )
    }

    if (hasInitialData) {
      if (view === 'dashboard') {
        return <Dashboard data={reportData} selectedMonth={selectedMonth} availableMonths={availableMonths} />;
      }

      return (
          <div className="space-y-8">
            <FilterControls searchTerm={searchTerm} onSearchChange={setSearchTerm} />
            <SummaryCard summary={summary} isLoading={isGeneratingSummary} error={summaryError} />
            <RepairCostChart data={sortedData} />
            <ReportTable 
              data={sortedData} 
              onSort={handleSort}
              sortConfig={sortConfig}
              searchTerm={searchTerm}
              groupBy={groupBy}
            />
          </div>
      );
    }
    
    return (
        <div className="w-full h-full flex flex-col items-center justify-center text-slate-500">
             <p className="text-xl font-semibold">ไม่พบข้อมูล</p>
             <p>ไม่สามารถโหลดข้อมูลจาก Google Sheet หรือชีทไม่มีข้อมูล</p>
        </div>
    );
  }

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-slate-100 text-slate-800">
      <Sidebar 
        isGeneratingSummary={isGeneratingSummary}
        hasData={hasInitialData}
        hasFilteredData={hasFilteredData}
        onGenerateSummary={handleGenerateSummary}
        onRefreshAndReset={refreshAndResetData}
        availableMonths={availableMonths}
        selectedMonth={selectedMonth}
        onSelectMonth={setSelectedMonth}
        groupBy={groupBy}
        onSelectGroupBy={setGroupBy}
        view={view}
        onSelectView={setView}
      />
      
      <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
        {renderMainContent()}
      </main>
    </div>
  );
};

export default App;
