
import React, { useMemo } from 'react';
import { RepairRecord } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import ChartBarIcon from './icons/ChartBarIcon';
import CalendarIcon from './icons/CalendarIcon';
import WalletIcon from './icons/WalletIcon';
import WrenchScrewdriverIcon from './icons/WrenchScrewdriverIcon';
import TruckIcon from './icons/TruckIcon';
import CalculatorIcon from './icons/CalculatorIcon';

interface DashboardProps {
  data: RepairRecord[];
  selectedMonth: string;
  availableMonths: string[];
}

const formatCurrency = (value: number) => new Intl.NumberFormat('th-TH', { maximumFractionDigits: 0 }).format(value);
const formatMonthForDisplay = (monthYear: string) => {
    const [year, month] = monthYear.split('-');
    const date = new Date(Number(year), Number(month) - 1);
    return date.toLocaleDateString('th-TH', { month: 'short', year: '2-digit' });
};

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    const value = payload[0].value;
    const name = payload[0].name;

    let displayValue = '';
    let displayName = '';

    if (name === 'totalCost' || name === 'ค่าซ่อมรวม') {
      displayValue = `${formatCurrency(value as number)} บาท`;
      displayName = 'ค่าซ่อมรวม';
    } else if (name === 'vehicleCount' || name === 'จำนวนรถ') {
      displayValue = `${value} คัน`;
      displayName = 'จำนวนรถ';
    }

    return (
      <div className="bg-white/90 backdrop-blur-sm p-3 rounded-lg shadow-lg border border-slate-200 text-sm">
        <p className="font-bold text-slate-800">{label}</p>
        <p className="text-sky-600">{`${displayName}: ${displayValue}`}</p>
      </div>
    );
  }
  return null;
};


const Dashboard: React.FC<DashboardProps> = ({ data, selectedMonth, availableMonths }) => {

  const monthlySummary = useMemo(() => {
    const summary: Record<string, { totalCost: number; vehicles: Set<string> }> = {};

    data.forEach(record => {
      if (!record.sapDocDate) return;
      const date = new Date(record.sapDocDate);
      if (isNaN(date.getTime())) return;
      const monthYear = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      
      if (!summary[monthYear]) {
        summary[monthYear] = { totalCost: 0, vehicles: new Set() };
      }
      summary[monthYear].totalCost += record.price;
      if (record.vehicleNo) {
        summary[monthYear].vehicles.add(record.vehicleNo);
      }
    });

    return availableMonths.map(month => ({
      month: formatMonthForDisplay(month),
      monthKey: month,
      totalCost: summary[month]?.totalCost || 0,
      vehicleCount: summary[month]?.vehicles.size || 0,
    }));
  }, [data, availableMonths]);

  const dataForSelectedPeriod = useMemo(() => {
      return selectedMonth ? data.filter(record => record.sapDocDate && record.sapDocDate.startsWith(selectedMonth)) : data;
  }, [data, selectedMonth]);

  const dashboardStats = useMemo(() => {
    if (dataForSelectedPeriod.length === 0) {
        return { totalCost: 0, totalRepairs: 0, uniqueVehicles: 0, averageCost: 0 };
    }

    const totalCost = dataForSelectedPeriod.reduce((sum, record) => sum + record.price, 0);
    const totalRepairs = dataForSelectedPeriod.length;
    const uniqueVehicles = new Set(dataForSelectedPeriod.map(r => r.vehicleNo).filter(Boolean)).size;
    const averageCost = totalRepairs > 0 ? totalCost / totalRepairs : 0;

    return { totalCost, totalRepairs, uniqueVehicles, averageCost };
  }, [dataForSelectedPeriod]);

  const topVehiclesData = useMemo(() => {
    if (dataForSelectedPeriod.length === 0) return [];

    const costByVehicle = dataForSelectedPeriod.reduce<Record<string, number>>((acc, record) => {
      const vehicleNo = String(record.vehicleNo || 'ไม่ระบุ').trim();
      if (vehicleNo && vehicleNo !== 'ไม่ระบุ') {
        if (!acc[vehicleNo]) {
          acc[vehicleNo] = 0;
        }
        acc[vehicleNo] += record.price;
      }
      return acc;
    }, {});
    
    return Object.entries(costByVehicle)
      .map(([vehicleNo, totalCost]) => ({ vehicleNo, totalCost }))
      .sort((a, b) => b.totalCost - a.totalCost)
      .slice(0, 7)
      .reverse();
  }, [dataForSelectedPeriod]);

  const formatMonthTitle = (monthYear: string) => {
    const [year, month] = monthYear.split('-');
    const date = new Date(Number(year), Number(month) - 1);
    return date.toLocaleDateString('th-TH', { month: 'long', year: 'numeric' });
  };

  const periodDescription = selectedMonth ? `เดือน ${formatMonthTitle(selectedMonth)}` : 'ภาพรวมทั้งหมด';

  return (
    <div className="space-y-6">
       {/* Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-5 rounded-xl shadow-lg border border-slate-200/50 flex items-center space-x-4">
            <div className="bg-green-100 p-4 rounded-full">
                <WalletIcon className="w-8 h-8 text-green-600" />
            </div>
            <div>
                <p className="text-sm font-medium text-slate-500">ยอดค่าใช้จ่ายรวม</p>
                <p className="text-2xl font-bold text-slate-800">{`฿${formatCurrency(dashboardStats.totalCost)}`}</p>
                 <p className="text-xs text-slate-400">{periodDescription}</p>
            </div>
        </div>
        <div className="bg-white p-5 rounded-xl shadow-lg border border-slate-200/50 flex items-center space-x-4">
            <div className="bg-sky-100 p-4 rounded-full">
                <WrenchScrewdriverIcon className="w-8 h-8 text-sky-600" />
            </div>
            <div>
                <p className="text-sm font-medium text-slate-500">จำนวนการซ่อม</p>
                <p className="text-2xl font-bold text-slate-800">{`${dashboardStats.totalRepairs.toLocaleString('th-TH')} ครั้ง`}</p>
                <p className="text-xs text-slate-400">{periodDescription}</p>
            </div>
        </div>
         <div className="bg-white p-5 rounded-xl shadow-lg border border-slate-200/50 flex items-center space-x-4">
            <div className="bg-amber-100 p-4 rounded-full">
                <TruckIcon className="w-8 h-8 text-amber-600" />
            </div>
            <div>
                <p className="text-sm font-medium text-slate-500">จำนวนรถที่ซ่อม</p>
                <p className="text-2xl font-bold text-slate-800">{`${dashboardStats.uniqueVehicles.toLocaleString('th-TH')} คัน`}</p>
                <p className="text-xs text-slate-400">{periodDescription}</p>
            </div>
        </div>
         <div className="bg-white p-5 rounded-xl shadow-lg border border-slate-200/50 flex items-center space-x-4">
            <div className="bg-rose-100 p-4 rounded-full">
                <CalculatorIcon className="w-8 h-8 text-rose-600" />
            </div>
            <div>
                <p className="text-sm font-medium text-slate-500">ค่าใช้จ่ายเฉลี่ย</p>
                <p className="text-2xl font-bold text-slate-800">{`฿${formatCurrency(dashboardStats.averageCost)}`}</p>
                 <p className="text-xs text-slate-400">{periodDescription}</p>
            </div>
        </div>
      </div>
      
      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Total Cost Chart */}
        <div className="lg:col-span-2 bg-white p-6 rounded-xl shadow-lg border border-slate-200/50">
          <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center">
              <ChartBarIcon className="w-5 h-5 mr-2 text-sky-500" />
              ยอดรวมค่าใช้จ่ายของแต่ละเดือน
          </h3>
          <ResponsiveContainer width="100%" height={300}>
              <BarChart data={monthlySummary} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" vertical={false}/>
                <XAxis dataKey="month" tick={{ fill: '#475569', fontSize: 12 }} />
                <YAxis tickFormatter={formatCurrency} tick={{ fill: '#475569', fontSize: 12 }} />
                <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(14, 165, 233, 0.1)' }} />
                <Bar dataKey="totalCost" name="ค่าซ่อมรวม" fill="#0ea5e9" radius={[4, 4, 0, 0]} barSize={30}/>
              </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Monthly Repair Volume Chart */}
        <div className="bg-white p-6 rounded-xl shadow-lg border border-slate-200/50">
          <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center">
              <CalendarIcon className="w-5 h-5 mr-2 text-indigo-500" />
              ปริมาณรถที่แจ้งซ่อมในแต่ละเดือน
          </h3>
          <ResponsiveContainer width="100%" height={350}>
              <BarChart data={monthlySummary} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" vertical={false}/>
                <XAxis dataKey="month" tick={{ fill: '#475569', fontSize: 12 }} />
                <YAxis allowDecimals={false} tick={{ fill: '#475569', fontSize: 12 }} />
                <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(99, 102, 241, 0.1)' }}/>
                <Bar dataKey="vehicleCount" name="จำนวนรถ" fill="#6366f1" radius={[4, 4, 0, 0]} barSize={30}/>
              </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Top 7 Most Expensive Repairs */}
        <div className="bg-white p-6 rounded-xl shadow-lg border border-slate-200/50">
          <h3 className="text-lg font-bold text-slate-800 mb-1">
              7 อันดับรถที่ค่าซ่อมสูงสุด
          </h3>
          <p className="text-sm text-slate-500 mb-4">
              {selectedMonth ? `ของเดือน ${formatMonthTitle(selectedMonth)}` : ' (ภาพรวมทั้งหมด)'}
          </p>
          <div style={{ width: '100%', height: 350 }}>
            {topVehiclesData.length > 0 ? (
                <ResponsiveContainer>
                    <BarChart data={topVehiclesData} layout="vertical" margin={{ top: 5, right: 30, left: 10, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" horizontal={false}/>
                        <XAxis type="number" tickFormatter={formatCurrency} tick={{ fill: '#475569', fontSize: 12 }} />
                        <YAxis type="category" dataKey="vehicleNo" width={80} tick={{ fill: '#1e293b', fontWeight: 600, fontSize: 12 }}/>
                        <Tooltip formatter={(value: number) => [`${formatCurrency(value)} บาท`, 'ค่าซ่อมรวม']} cursor={{ fill: 'rgba(244, 63, 94, 0.1)' }}/>
                        <Bar dataKey="totalCost" name="ค่าซ่อมรวม" fill="#f43f5e" radius={[0, 4, 4, 0]} barSize={20}/>
                    </BarChart>
                </ResponsiveContainer>
            ) : (
                <div className="flex items-center justify-center h-full text-slate-500">
                    <div className="text-center">
                        <ChartBarIcon className="w-12 h-12 mx-auto mb-2 text-slate-300" />
                        <p className="font-semibold">ไม่มีข้อมูลสำหรับแสดงผล</p>
                        <p className="text-sm">โปรดเลือกเดือนหรือตรวจสอบข้อมูล</p>
                    </div>
                </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
