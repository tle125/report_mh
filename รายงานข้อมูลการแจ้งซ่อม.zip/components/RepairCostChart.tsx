
import React, { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { RepairRecord } from '../types';
import ChartBarIcon from './icons/ChartBarIcon';

const RepairCostChart: React.FC<{ data: RepairRecord[] }> = ({ data }) => {
  const chartData = useMemo(() => {
    const costByVehicle = data.reduce<Record<string, number>>((acc, record) => {
      // Ensure vehicleNo is a string and not empty before processing
      const vehicleNo = String(record.vehicleNo || 'ไม่ระบุ').trim();
      if (vehicleNo) {
          if (!acc[vehicleNo]) {
            acc[vehicleNo] = 0;
          }
          acc[vehicleNo] += record.price;
      }
      return acc;
    }, {});

    return Object.entries(costByVehicle)
      .map(([vehicleNo, totalCost]) => ({ vehicleNo, totalCost }))
      .sort((a, b) => b.totalCost - a.totalCost);
  }, [data]);
  
  const formatCurrency = (value: number) => {
      return new Intl.NumberFormat('th-TH').format(value);
  }

  return (
    <div className="w-full bg-white border border-slate-200/80 rounded-lg shadow-sm p-6">
      <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center">
        <ChartBarIcon className="w-5 h-5 mr-2 text-sky-500" />
        ค่าใช้จ่ายในการซ่อมตามเบอร์รถ
      </h3>
      <div style={{ width: '100%', height: 300 }}>
        {chartData.length > 0 ? (
          <ResponsiveContainer>
            <BarChart 
              data={chartData} 
              margin={{ top: 5, right: 20, left: 20, bottom: 5 }}
              aria-label="แผนภูมิแสดงค่าใช้จ่ายในการซ่อมตามเบอร์รถ"
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis dataKey="vehicleNo" tick={{ fill: '#475569', fontSize: 12 }} angle={-25} textAnchor="end" height={50} interval={0} />
              <YAxis tickFormatter={formatCurrency} tick={{ fill: '#475569', fontSize: 12 }} />
              <Tooltip
                formatter={(value: number) => [`${formatCurrency(value)} บาท`, 'ค่าซ่อมรวม']}
                cursor={{ fill: 'rgba(71, 85, 105, 0.08)' }}
                contentStyle={{
                  backgroundColor: 'rgba(255, 255, 255, 0.95)',
                  border: '1px solid #e2e8f0',
                  borderRadius: '0.5rem',
                  fontSize: '0.875rem',
                  boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)'
                }}
                labelStyle={{ color: '#0f172a', fontWeight: 'bold' }}
              />
              <Bar dataKey="totalCost" fill="#0ea5e9" name="ค่าซ่อมรวม" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <div className="flex items-center justify-center h-full text-slate-500">
            <div className="text-center">
              <ChartBarIcon className="w-12 h-12 mx-auto mb-2 text-slate-300" />
              <p className="font-semibold">ไม่มีข้อมูลสำหรับแสดงผล</p>
              <p className="text-sm">ข้อมูลที่กรองแล้วไม่มีรายการค่าใช้จ่าย</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default RepairCostChart;
