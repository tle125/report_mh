import React, { useState, useMemo, useEffect } from 'react';
import { RepairRecord } from '../types';
import ChevronIcon from './icons/ChevronIcon';

interface SortConfig {
  key: keyof RepairRecord;
  direction: 'ascending' | 'descending';
}

type GroupByOption = 'month' | 'type';

interface ReportTableProps {
  data: RepairRecord[];
  onSort: (key: keyof RepairRecord) => void;
  sortConfig: SortConfig | null;
  searchTerm: string;
  groupBy: GroupByOption;
}

const ReportTable: React.FC<ReportTableProps> = ({ data, onSort, sortConfig, searchTerm, groupBy }) => {
    const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({});

    useEffect(() => {
        setExpandedGroups({});
    }, [groupBy]);

  const tableHeaders: { label: string; key: keyof RepairRecord, searchable?: boolean }[] = [
    { label: 'ลำดับที่', key: 'id' },
    { label: 'เบอร์รถ', key: 'vehicleNo', searchable: true },
    { label: 'รายการซ่อม', key: 'repairItem', searchable: true },
    { label: 'ประเภท', key: 'type', searchable: true },
    { label: 'เลขที่ใบแจ้งซ่อม(APP)', key: 'appWorkOrderNo', searchable: true },
    { label: 'เลขที่ใบแจ้งซ่อม(SAP)', key: 'sapWorkOrderNo', searchable: true },
    { label: 'วันที่เปิดเอกสาร(SAP)', key: 'sapDocDate' },
    { label: 'วันที่แจ้งซ่อม(APP)', key: 'appRequestDate' },
    { label: 'ซ่อมเสร็จ(APP)', key: 'appCompletionDate' },
    { label: 'ราคา (บาท)', key: 'price' },
  ];

    const getWeekOfMonth = (date: Date): number => {
        // A simple way to group by week within a month.
        // It's not a standard calendar week, but consistent for this purpose.
        return Math.ceil(date.getDate() / 7);
    };

    const groupedByMonthData = useMemo(() => {
        const groups: Record<string, Record<string, Record<string, RepairRecord[]>>> = {};
        data.forEach(record => {
            if (!record.sapDocDate) return;
            const date = new Date(record.sapDocDate);
            if (isNaN(date.getTime())) return;

            const monthYear = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
            const weekNumber = getWeekOfMonth(date);
            const weekKey = `สัปดาห์ที่ ${weekNumber}`;
            const vehicleNo = record.vehicleNo || 'ไม่ระบุทะเบียน';

            if (!groups[monthYear]) {
                groups[monthYear] = {};
            }
            if (!groups[monthYear][weekKey]) {
                groups[monthYear][weekKey] = {};
            }
            if (!groups[monthYear][weekKey][vehicleNo]) {
                groups[monthYear][weekKey][vehicleNo] = [];
            }
            groups[monthYear][weekKey][vehicleNo].push(record);
        });
        return groups;
    }, [data]);

  const groupedByTypeData = useMemo(() => {
    const groups: Record<string, RepairRecord[]> = {};
    data.forEach(record => {
        const type = record.type.trim() || 'ไม่ระบุประเภท';
        if (!groups[type]) {
            groups[type] = [];
        }
        groups[type].push(record);
    });
    return groups;
  }, [data]);

  const toggleGroup = (key: string) => {
    setExpandedGroups(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('th-TH', { minimumFractionDigits: 2 }).format(price);
  };

  const formatDateDisplay = (dateString: string | undefined): string => {
    if (!dateString || dateString.trim() === '') {
      return '';
    }
    const date = new Date(dateString);
    if (isNaN(date.getTime())) {
      return dateString;
    }
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  };

    const formatMonthForDisplay = (monthYear: string) => {
        const [year, month] = monthYear.split('-');
        const date = new Date(Number(year), Number(month) - 1);
        return date.toLocaleDateString('th-TH', { month: 'long', year: 'numeric' });
    };

  const highlightMatch = (text: string) => {
    if (!searchTerm) {
      return text;
    }
    const regex = new RegExp(`(${searchTerm})`, 'gi');
    const parts = text.split(regex);
    return (
      <span>
        {parts.map((part, i) =>
          regex.test(part) ? (
            <mark key={i} className="bg-yellow-200 px-0 py-0 rounded-sm">
              {part}
            </mark>
          ) : (
            part
          )
        )}
      </span>
    );
  };

  const getSortIndicator = (key: keyof RepairRecord) => {
    if (!sortConfig || sortConfig.key !== key) {
      return <span className="opacity-30">▲▼</span>;
    }
    return sortConfig.direction === 'ascending' ? '▲' : '▼';
  };

  const renderDataRow = (record: RepairRecord, indentationClass: string) => (
    <tr key={record.id} className="bg-white border-b border-slate-200/80 hover:bg-slate-50/70 transition-colors duration-150">
        <td className={`${indentationClass} pr-6 py-4 text-center font-medium text-slate-800`}>{record.id}</td>
        <td className="px-6 py-4">{highlightMatch(record.vehicleNo)}</td>
        <td className="px-6 py-4 font-medium text-slate-900">{highlightMatch(record.repairItem)}</td>
        <td className="px-6 py-4">
            <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
            record.type.includes('ซ่อม')
                ? 'bg-amber-100 text-amber-800'
                : 'bg-sky-100 text-sky-800'
            }`}>
            {highlightMatch(record.type)}
            </span>
        </td>
        <td className="px-6 py-4">{highlightMatch(record.appWorkOrderNo)}</td>
        <td className="px-6 py-4">{highlightMatch(record.sapWorkOrderNo)}</td>
        <td className="px-6 py-4">{formatDateDisplay(record.sapDocDate)}</td>
        <td className="px-6 py-4">{formatDateDisplay(record.appRequestDate)}</td>
        <td className="px-6 py-4">{formatDateDisplay(record.appCompletionDate)}</td>
        <td className="px-6 py-4 text-right font-semibold text-slate-800">{formatPrice(record.price)}</td>
    </tr>
  );

  const renderByMonth = () => {
    const sortedMonths = Object.keys(groupedByMonthData).sort((a,b) => b.localeCompare(a)); // sort descending

    return sortedMonths.map(monthKey => {
        const monthData = groupedByMonthData[monthKey];
        const isMonthExpanded = expandedGroups[monthKey] ?? false;
        
        const monthRecords = Object.values(monthData).flatMap(week => Object.values(week).flat());
        const totalItemsInMonth = monthRecords.length;
        const totalPriceInMonth = monthRecords.reduce((sum, record) => sum + record.price, 0);

        return (
            <React.Fragment key={monthKey}>
                {/* Month Row */}
                <tr
                    onClick={() => toggleGroup(monthKey)}
                    className="bg-slate-200 hover:bg-slate-300/80 cursor-pointer transition-colors"
                >
                    <td colSpan={tableHeaders.length} className="px-6 py-3 font-bold text-slate-800 tracking-wide">
                        <div className="flex items-center justify-between">
                            <div className="flex items-center">
                                <ChevronIcon className={`w-5 h-5 mr-3 transition-transform duration-200 ${isMonthExpanded ? 'rotate-180' : ''}`} />
                                {formatMonthForDisplay(monthKey)}
                            </div>
                            <div className="flex items-center space-x-4">
                                <span className="text-sm font-medium text-slate-600 bg-slate-100 px-3 py-1 rounded-full">{totalItemsInMonth} รายการ</span>
                                <span className="text-sm font-bold text-sky-800 bg-sky-100 px-3 py-1 rounded-full">{formatPrice(totalPriceInMonth)} บาท</span>
                            </div>
                        </div>
                    </td>
                </tr>
                {/* Week Rows */}
                {isMonthExpanded && Object.keys(monthData).sort().map(weekKey => {
                    const weekData = monthData[weekKey];
                    const weekGroupKey = `${monthKey}-${weekKey}`;
                    const isWeekExpanded = expandedGroups[weekGroupKey] ?? false;

                    const weekRecords = Object.values(weekData).flat();
                    const totalItemsInWeek = weekRecords.length;
                    const totalPriceInWeek = weekRecords.reduce((sum, record) => sum + record.price, 0);

                    return (
                        <React.Fragment key={weekGroupKey}>
                            <tr
                                onClick={() => toggleGroup(weekGroupKey)}
                                className="bg-slate-100 hover:bg-slate-200/70 cursor-pointer transition-colors"
                            >
                                <td colSpan={tableHeaders.length} className="pl-12 pr-6 py-2 font-semibold text-slate-700">
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center">
                                            <ChevronIcon className={`w-4 h-4 mr-3 transition-transform duration-200 text-slate-500 ${isWeekExpanded ? 'rotate-180' : ''}`} />
                                            {weekKey}
                                        </div>
                                        <div className="flex items-center space-x-3">
                                            <span className="text-xs font-medium text-slate-600 bg-white px-2 py-1 rounded-full border border-slate-200">{totalItemsInWeek} รายการ</span>
                                            <span className="text-xs font-bold text-sky-700 bg-sky-50 px-2 py-1 rounded-full border border-sky-100">{formatPrice(totalPriceInWeek)} บาท</span>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            {/* Vehicle Rows */}
                            {isWeekExpanded && Object.keys(weekData).sort().map(vehicleKey => {
                                const vehicleData = weekData[vehicleKey];
                                const vehicleGroupKey = `${weekGroupKey}-${vehicleKey}`;
                                const isVehicleExpanded = expandedGroups[vehicleGroupKey] ?? false;
                                const totalPriceInVehicle = vehicleData.reduce((sum, record) => sum + record.price, 0);

                                return (
                                    <React.Fragment key={vehicleGroupKey}>
                                        <tr
                                            onClick={() => toggleGroup(vehicleGroupKey)}
                                            className="bg-slate-50 hover:bg-slate-100 cursor-pointer border-t border-slate-200/50"
                                        >
                                            <td colSpan={tableHeaders.length} className="pl-20 pr-6 py-2 font-medium text-slate-700">
                                                <div className="flex items-center justify-between">
                                                    <div className="flex items-center">
                                                        <ChevronIcon className={`w-4 h-4 mr-3 transition-transform duration-200 text-slate-400 ${isVehicleExpanded ? 'rotate-180' : ''}`} />
                                                        {`ทะเบียน: ${vehicleKey}`}
                                                    </div>
                                                     <div className="flex items-center space-x-3">
                                                        <span className="text-xs font-semibold text-slate-500 bg-white px-2 py-1 rounded-full border border-slate-200">{vehicleData.length} รายการ</span>
                                                        <span className="text-xs font-bold text-sky-600 bg-sky-50 px-2 py-1 rounded-full border border-sky-100">{formatPrice(totalPriceInVehicle)} บาท</span>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        {isVehicleExpanded && vehicleData.map(record => renderDataRow(record, 'pl-24'))}
                                    </React.Fragment>
                                )
                            })}
                        </React.Fragment>
                    );
                })}
            </React.Fragment>
        );
    });
};

const renderByType = () => {
    const sortedTypes = Object.keys(groupedByTypeData).sort((a,b) => a.localeCompare(b));

    return sortedTypes.map(typeKey => {
        const typeData = groupedByTypeData[typeKey];
        const isExpanded = expandedGroups[typeKey] ?? false;
        
        const totalItems = typeData.length;
        const totalPrice = typeData.reduce((sum, record) => sum + record.price, 0);

        return (
            <React.Fragment key={typeKey}>
                <tr
                    onClick={() => toggleGroup(typeKey)}
                    className="bg-slate-200 hover:bg-slate-300/80 cursor-pointer transition-colors"
                >
                    <td colSpan={tableHeaders.length} className="px-6 py-3 font-bold text-slate-800 tracking-wide">
                        <div className="flex items-center justify-between">
                            <div className="flex items-center">
                                <ChevronIcon className={`w-5 h-5 mr-3 transition-transform duration-200 ${isExpanded ? 'rotate-180' : ''}`} />
                                {`ประเภท: ${typeKey}`}
                            </div>
                            <div className="flex items-center space-x-4">
                                <span className="text-sm font-medium text-slate-600 bg-slate-100 px-3 py-1 rounded-full">{totalItems} รายการ</span>
                                <span className="text-sm font-bold text-sky-800 bg-sky-100 px-3 py-1 rounded-full">{formatPrice(totalPrice)} บาท</span>
                            </div>
                        </div>
                    </td>
                </tr>
                {isExpanded && typeData.map(record => renderDataRow(record, 'pl-8'))}
            </React.Fragment>
        );
    });
};


  return (
    <div className="bg-white p-1 rounded-xl shadow-lg border border-slate-200/50">
        <div className="w-full overflow-x-auto">
            <table className="w-full min-w-[1200px] text-sm text-left text-slate-600 border-collapse">
                <thead className="bg-slate-100 text-xs text-slate-700 uppercase tracking-wider sticky top-0 z-10">
                <tr>
                    {tableHeaders.map((header) => (
                    <th key={header.key} scope="col" className={`px-6 py-4 font-semibold ${header.key === 'id' ? 'pl-8' : ''}`}>
                        <button
                        type="button"
                        onClick={() => onSort(header.key)}
                        className="flex items-center space-x-2 text-left w-full font-semibold"
                        >
                        <span>{header.label}</span>
                        <span className="text-sky-600">{getSortIndicator(header.key)}</span>
                        </button>
                    </th>
                    ))}
                </tr>
                </thead>
                <tbody>
                {data.length > 0 ? (
                    groupBy === 'month' ? renderByMonth() : renderByType()
                ) : (
                    <tr className="bg-white">
                    <td colSpan={tableHeaders.length} className="text-center py-16 text-slate-500">
                        <p className="font-semibold text-lg">ไม่พบข้อมูล</p>
                        <p>โปรดลองเปลี่ยนคำค้นหาหรือตัวกรองมุมมองข้อมูล</p>
                    </td>
                    </tr>
                )}
                </tbody>
            </table>
        </div>
    </div>
  );
};

export default ReportTable;