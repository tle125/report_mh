
import React from 'react';
import SpinnerIcon from './icons/SpinnerIcon';
import SparklesIcon from './icons/SparklesIcon';

interface SummaryCardProps {
  summary: string | null;
  isLoading: boolean;
  error: string | null;
}

const SummaryCard: React.FC<SummaryCardProps> = ({ summary, isLoading, error }) => {
  const renderContent = () => {
    if (isLoading) {
      return (
        <div className="flex flex-col items-center justify-center text-slate-500">
          <SpinnerIcon className="w-8 h-8 mb-3" />
          <p className="font-semibold">กำลังสร้างสรุปด้วย AI...</p>
          <p className="text-xs">กรุณารอสักครู่</p>
        </div>
      );
    }

    if (error) {
      return (
        <div className="text-center text-red-600">
          <p className="font-bold mb-2">เกิดข้อผิดพลาด</p>
          <p className="text-sm bg-red-50 p-3 rounded-md">{error}</p>
        </div>
      );
    }
    
    if (summary) {
        // Simple markdown parsing for bullet points
        const summaryLines = summary.split('\n').filter(line => line.trim() !== '');

        return (
            <div className="text-slate-700 space-y-3">
              {summaryLines.map((line, index) => {
                  if (line.trim().startsWith('*') || line.trim().startsWith('-')) {
                      return (
                          <div key={index} className="flex items-start">
                              <span className="mr-3 text-sky-500 mt-1">&#8226;</span>
                              <p className="flex-1">{line.replace(/[\*\-]\s*/, '')}</p>
                          </div>
                      );
                  }
                  return <p key={index}>{line}</p>;
              })}
            </div>
        );
    }

    return (
        <div className="flex flex-col items-center justify-center text-slate-400">
            <SparklesIcon className="w-8 h-8 mb-3 text-slate-300" />
            <p className="font-semibold">กดปุ่ม "สร้างสรุป" เพื่อวิเคราะห์ข้อมูล</p>
            <p className="text-xs">AI จะช่วยสรุปภาพรวมข้อมูลการซ่อมทั้งหมดให้คุณ</p>
        </div>
    );
  };
  
  return (
    <div className="w-full bg-white border border-slate-200/80 rounded-lg shadow-sm p-6 mb-8 min-h-[180px] flex flex-col justify-center transition-all duration-300">
        <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center">
            <SparklesIcon className="w-5 h-5 mr-2 text-sky-500"/>
            สรุปข้อมูลอัจฉริยะ
        </h3>
        {renderContent()}
    </div>
  );
};

export default SummaryCard;
