
import React from 'react';

const SparklesIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <path d="M9.93 13.5A7.14 7.14 0 0 1 2.86 6.43m18.28 7.07a7.14 7.14 0 0 1-7.07 7.07m-7.07-18.28a7.14 7.14 0 0 1 7.07-7.07m7.07 18.28a7.14 7.14 0 0 1-7.07 7.07M12 2v4m0 16v-4M4.93 4.93l2.83 2.83m12.73 12.73-2.83-2.83M4.93 19.07l2.83-2.83m12.73-12.73-2.83 2.83" />
  </svg>
);

export default SparklesIcon;
