import React from 'react';

const WrenchScrewdriverIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg 
        xmlns="http://www.w3.org/2000/svg" 
        width="24" 
        height="24" 
        viewBox="0 0 24 24" 
        fill="none" 
        stroke="currentColor" 
        strokeWidth="2" 
        strokeLinecap="round" 
        strokeLinejoin="round" 
        {...props}
    >
        <path d="M18.8 2.2c-1.3-1.3-3.5-1.3-4.8 0l-1.2 1.2c-1.3 1.3-1.3 3.5 0 4.8l2.4 2.4c1.3 1.3 3.5 1.3 4.8 0l1.2-1.2c1.3-1.3 1.3-3.5 0-4.8l-2.4-2.4z"></path>
        <path d="m14.2 9.2 1.6 1.6"></path>
        <path d="M2 22l4-4"></path>
        <path d="M8.4 12.6 12 16l-1.8 1.8c-1.3 1.3-3.5 1.3-4.8 0L4 16.2c-1.3-1.3-1.3-3.5 0-4.8L5.8 10"></path>
    </svg>
);

export default WrenchScrewdriverIcon;