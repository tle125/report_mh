
import React from 'react';
import SpinnerIcon from './icons/SpinnerIcon';
import SparklesIcon from './icons/SparklesIcon';
import WrenchScrewdriverIcon from './icons/WrenchScrewdriverIcon';
import CalendarIcon from './icons/CalendarIcon';
import LayoutDashboardIcon from './icons/LayoutDashboardIcon';
import TableIcon from './icons/TableIcon';

type GroupByOption = 'month' | 'type';
type ViewOption = 'dashboard' | 'table';

interface SidebarProps {
  isGeneratingSummary: boolean;
  hasData: boolean;
  hasFilteredData: boolean;
  onGenerateSummary: () => void;
  onRefreshAndReset: () => void;
  availableMonths: string[];
  selectedMonth: string;
  onSelectMonth: (month: string) => void;
  groupBy: GroupByOption;
  onSelectGroupBy: (groupBy: GroupByOption) => void;
  view: ViewOption;
  onSelectView: (view: ViewOption) => void;
}

const Sidebar: React.FC<SidebarProps> = ({
  isGeneratingSummary,
  hasData,
  hasFilteredData,
  onGenerateSummary,
  onRefreshAndReset,
  availableMonths,
  selectedMonth,
  onSelectMonth,
  groupBy,
  onSelectGroupBy,
  view,
  onSelectView,
}) => {
  const formatMonthForDisplay = (monthYear: string) => {
    const [year, month] = monthYear.split('-');
    const date = new Date(Number(year), Number(month) - 1);
    return date.toLocaleDateString('th-TH', { month: 'long', year: 'numeric' });
  };

  const viewButtonClasses = (buttonView: ViewOption) => 
    `w-full flex items-center justify-center px-4 py-2 font-semibold rounded-md transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-sky-400 ${
      view === buttonView 
        ? 'bg-sky-500 text-white shadow-md' 
        : 'bg-slate-700/50 text-slate-300 hover:bg-slate-700'
    }`;

  return (
    <aside className="w-full lg:w-80 bg-slate-800 text-slate-300 flex flex-col p-6 shadow-2xl z-20">
      <div className="flex-grow">
        <header className="mb-10">
          <h1 className="text-2xl font-bold text-white">
            รายงานข้อมูลการแจ้งซ่อม
          </h1>
          <p className="text-sm text-slate-400">Control Panel</p>
        </header>

        <nav className="space-y-8">
          {/* View Switcher */}
          {hasData && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2 p-1 bg-slate-700/80 rounded-lg">
                  <button onClick={() => onSelectView('dashboard')} className={viewButtonClasses('dashboard')}>
                      <LayoutDashboardIcon className="w-5 h-5 mr-2" />
                      Dashboard
                  </button>
                  <button onClick={() => onSelectView('table')} className={viewButtonClasses('table')}>
                      <TableIcon className="w-5 h-5 mr-2" />
                      ตารางข้อมูล
                  </button>
              </div>
            </div>
          )}

          {/* Data View Section */}
          {hasData && (
              <div className="space-y-4">
                  <h2 className="flex items-center text-sm font-semibold uppercase text-slate-400 tracking-wider">
                      <CalendarIcon className="w-4 h-4 mr-3"/>
                      ตัวกรองข้อมูล
                  </h2>
                  <div className="space-y-2">
                      <label htmlFor="monthSelect" className="block text-sm font-medium text-slate-300">เดือน</label>
                      <select id="monthSelect" value={selectedMonth} onChange={e => onSelectMonth(e.target.value)} className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500 text-slate-100">
                          <option value="">ทั้งหมด</option>
                          {availableMonths.map(month => (
                              <option key={month} value={month}>{formatMonthForDisplay(month)}</option>
                          ))}
                      </select>
                  </div>
                  {view === 'table' && (
                    <div className="space-y-2">
                        <label htmlFor="groupingSelect" className="block text-sm font-medium text-slate-300">จัดกลุ่มตาม</label>
                        <select 
                            id="groupingSelect" 
                            value={groupBy} 
                            onChange={e => onSelectGroupBy(e.target.value as GroupByOption)} 
                            className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500 text-slate-100"
                        >
                            <option value="month">เดือน, สัปดาห์, และทะเบียนรถ</option>
                            <option value="type">ประเภทการซ่อม</option>
                        </select>
                    </div>
                  )}
              </div>
          )}


          {/* Actions Section */}
          {hasData && view === 'table' && (
            <div className="space-y-4">
               <h2 className="flex items-center text-sm font-semibold uppercase text-slate-400 tracking-wider">
                <WrenchScrewdriverIcon className="w-4 h-4 mr-3"/>
                Actions
              </h2>
               <button
                onClick={onGenerateSummary}
                disabled={isGeneratingSummary || !hasFilteredData}
                className="w-full flex items-center justify-center px-4 py-2 bg-white/10 text-slate-100 font-semibold rounded-lg shadow-md hover:bg-white/20 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-sky-400 disabled:bg-slate-500/50 disabled:cursor-not-allowed transition-all duration-300"
              >
                {isGeneratingSummary ? (
                  <>
                    <SpinnerIcon className="w-5 h-5 mr-3" />
                    กำลังประมวลผล...
                  </>
                ) : (
                  <>
                    <SparklesIcon className="w-5 h-5 mr-3" />
                    สร้างสรุปด้วย AI
                  </>
                )}
              </button>
            </div>
          )}
        </nav>
      </div>

      {/* Footer / Reset Button */}
      <div className="mt-8">
         <button 
            onClick={onRefreshAndReset} 
            className="w-full text-center text-sm text-slate-400 hover:text-white hover:bg-slate-700/50 rounded-md py-2 transition-colors duration-200">
            รีเฟรชและรีเซ็ตค่า
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
