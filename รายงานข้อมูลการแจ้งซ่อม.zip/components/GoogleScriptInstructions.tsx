
import React, { useState } from 'react';

const SCRIPT_CODE = `const SHEET_ID = '1UupYLHQu66oJ2LVzsAk56sPrfl6UCNc_DyopsBuHORI';
const SHEET_NAME = 'ข้อมูลแจ้งซ่อม';

/**
 * Parses a date from various formats (Date object, YYYY-MM-DD, DD/MM/YYYY).
 * @param {*} input The date value to parse.
 * @return {Date|null} A Date object or null if parsing fails.
 */
function parseDate(input) {
  if (!input) return null;
  if (input instanceof Date && !isNaN(input)) {
    return input;
  }
  
  const s = String(input).trim();
  if (s === '') return null;

  // Try parsing DD/MM/YYYY or DD-MM-YYYY
  let parts = s.match(/^(\\d{1,2})[\\/-](\\d{1,2})[\\/-](\\d{4})$/);
  if (parts) {
    // new Date(year, month-1, day)
    const d = new Date(Number(parts[3]), Number(parts[2]) - 1, Number(parts[1]));
    if (!isNaN(d.getTime())) return d;
  }
  
  // Try parsing YYYY-MM-DD (or other standard JS parsable formats)
  try {
    const d = new Date(s);
    if (!isNaN(d.getTime())) return d;
  } catch(e) {
    // ignore errors
  }
  
  return null;
}


function doGet(e) {
  try {
    const sheet = SpreadsheetApp.openById(SHEET_ID).getSheetByName(SHEET_NAME);
    if (!sheet) {
      throw new Error('ไม่พบชีทชื่อ "' + SHEET_NAME + '"');
    }
    
    // Get all data, assuming row 1 is the header
    const values = sheet.getDataRange().getValues();
    
    // Remove header row
    const headers = values.shift(); 
    
    const records = values.map((row, index) => {
      // Skip if the row is completely empty
      if (row.join("").trim() === "") return null;

      const [
        id, vehicleNo, repairItem, type, appWorkOrderNo,
        sapWorkOrderNo, sapDocDate, appRequestDate, appCompletionDate, price
      ] = row;

      // Helper to format date objects to YYYY-MM-DD string
      const formatDate = (date) => {
        const parsedDate = parseDate(date);
        if (parsedDate) {
          return Utilities.formatDate(parsedDate, Session.getScriptTimeZone(), 'yyyy-MM-dd');
        }
        return ''; // Return empty for invalid or empty dates
      };
      
      return {
        // Use row index as a fallback ID if the ID column is empty
        id: Number(id) || (index + 1), 
        vehicleNo: String(vehicleNo || '').trim(),
        repairItem: String(repairItem || '').trim(),
        type: String(type || '').trim(),
        appWorkOrderNo: String(appWorkOrderNo || '').trim(),
        sapWorkOrderNo: String(sapWorkOrderNo || '').trim(),
        sapDocDate: formatDate(sapDocDate),
        appRequestDate: formatDate(appRequestDate),
        appCompletionDate: formatDate(appCompletionDate),
        price: Number(price) || 0,
      };
    }).filter(record => record !== null); // Filter out any empty rows that became null

    // Return a structured response
    const response = { success: true, data: records };
    
    return ContentService
      .createTextOutput(JSON.stringify(response))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (error) {
    // Return a structured error response
    const errorResponse = { success: false, error: error.message };
    return ContentService
      .createTextOutput(JSON.stringify(errorResponse))
      .setMimeType(ContentService.MimeType.JSON);
  }
}`;


const GoogleScriptInstructions: React.FC = () => {
    const [copied, setCopied] = useState(false);

    const handleCopy = () => {
        navigator.clipboard.writeText(SCRIPT_CODE);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <div className="bg-white p-6 rounded-lg shadow-lg border border-slate-200/50 mb-8">
            <h2 className="text-xl font-bold text-slate-900 mb-4">เชื่อมต่อกับ Google Sheet</h2>
            <p className="text-slate-600 mb-4">ทำตามขั้นตอนต่อไปนี้เพื่อดึงข้อมูลจาก Google Sheet ของคุณมาแสดงผลในแอปพลิเคชันนี้:</p>
            
            <ol className="list-decimal list-inside space-y-4 text-slate-700">
                <li>
                    <strong>สร้าง Google Apps Script:</strong>
                    <p className="text-sm text-slate-500 pl-2">ไปที่ <a href="https://script.google.com/home/my" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline">script.google.com</a> และสร้างโปรเจกต์ใหม่ (New project)</p>
                </li>
                <li>
                    <strong>วางโค้ด:</strong>
                    <p className="text-sm text-slate-500 pl-2 mb-2">ลบโค้ดที่มีอยู่ทั้งหมดและวางโค้ดด้านล่างนี้ลงไปแทน:</p>
                    <div className="relative">
                        <pre className="bg-slate-800 text-white p-4 rounded-md text-xs overflow-x-auto">
                            <code>{SCRIPT_CODE}</code>
                        </pre>
                        <button onClick={handleCopy} className="absolute top-2 right-2 bg-slate-600 hover:bg-slate-500 text-white text-xs font-semibold py-1 px-2 rounded-md transition-colors">
                            {copied ? 'คัดลอกแล้ว!' : 'คัดลอก'}
                        </button>
                    </div>
                </li>
                 <li>
                    <strong>ทำให้สคริปต์ใช้งานได้ (Deploy):</strong>
                    <ul className="list-disc list-inside text-sm text-slate-500 pl-6 mt-2 space-y-1">
                        <li>คลิกปุ่มสีฟ้า "Deploy" ที่มุมบนขวา และเลือก "New deployment"</li>
                        <li>คลิกที่ไอคอนรูปเฟือง (⚙️) ข้างๆ "Select type" และเลือก "Web app"</li>
                        <li>ในส่วน "Who has access" ให้เลือกเป็น <strong className="text-slate-700">"Anyone"</strong></li>
                        <li>คลิก "Deploy" และ "Authorize access" เพื่อให้สิทธิ์สคริปต์เข้าถึง Google Sheet ของคุณ</li>
                    </ul>
                </li>
                 <li>
                    <strong>คัดลอก URL:</strong>
                    <p className="text-sm text-slate-500 pl-2">หลังจาก Deploy สำเร็จ คุณจะได้รับ "Web app URL" มา ให้คัดลอก URL นั้น</p>
                </li>
                 <li>
                    <strong>เชื่อมต่อแอปพลิเคชัน:</strong>
                    <p className="text-sm text-slate-500 pl-2">นำ Web app URL ที่คัดลอกมาวางในช่องด้านล่างนี้ แล้วกด "ดึงข้อมูล"</p>
                </li>
            </ol>
        </div>
    );
};
export default GoogleScriptInstructions;
